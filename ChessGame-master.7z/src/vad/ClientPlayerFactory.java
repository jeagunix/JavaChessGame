package vad;

public interface ClientPlayerFactory
{
	Player create(int color);
}
