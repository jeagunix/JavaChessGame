package vad;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Random;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import com.nwgjb.xrmi.RMIConnection;
import static vad.OldAIPlayer.depth;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Main extends JFrame {
	JButton j1, j2, j3;

	public Main() {
		this.setTitle("������ �����ÿ�");
		this.setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		j1 = new JButton("�ʱ�");
		j2 = new JButton("�߱�");
		j3 = new JButton("����");

		j1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				depth = 1;
				System.out.println(depth);
			}

		});

		j2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				depth = 4;
				System.out.println(depth);
			}

		});
		
		j3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				depth = 9;
				System.out.println(depth);
			}

		});
		add(j1);
		add(j2);
		add(j3);

		setSize(300, 100);
		setVisible(true);
	}

	public static void main(String[] args) throws InterruptedException {
		new Main();
		Thread.sleep(5000);
		new Main2();
	}
}
